Upload this zip to Overleaf. Compile main.tex. Reference metadata should be verified before formal journal submission.
